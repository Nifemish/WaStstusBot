# Status Scheduler (Android)
Schedules WhatsApp Status posts by driving WhatsApp's screens with an Accessibility Service.
Phone must be on with no PIN/pattern lock at post time. Labels ("My status", "Send") are configurable per language.
The Log shows what the service sees on WhatsApp screens, so a broken step can be fixed by changing the labels or the code.
