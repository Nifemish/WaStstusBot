package com.example.statusbot

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.time.Instant
import java.time.LocalTime
import java.time.ZoneId

object Scheduler {
    fun computeNext(s: Store, from: Long = System.currentTimeMillis()): Long {
        if (s.mode == "times") {
            val zone = ZoneId.systemDefault()
            val times = s.times.split(",", " ").mapNotNull { runCatching { LocalTime.parse(it.trim().padStart(5, '0')) }.getOrNull() }
            if (times.isNotEmpty()) {
                val today = Instant.ofEpochMilli(from).atZone(zone).toLocalDate()
                var best: Long? = null
                for (d in 0..2) for (t in times) {
                    val ms = today.plusDays(d.toLong()).atTime(t).atZone(zone).toInstant().toEpochMilli()
                    if (ms > from && (best == null || ms < best)) best = ms
                }
                if (best != null) return best
            }
        }
        return from + (s.intervalHours * 3600_000).toLong()
    }

    fun schedule(ctx: Context) {
        val s = Store(ctx)
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            ctx, 1, Intent(ctx, AlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        if (!s.enabled || s.posts.isEmpty()) { am.cancel(pi); return }
        if (s.nextRun == 0L) s.nextRun = computeNext(s)
        val t = maxOf(s.nextRun, System.currentTimeMillis() + 5000)
        val show = PendingIntent.getActivity(ctx, 2, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        am.setAlarmClock(AlarmManager.AlarmClockInfo(t, show), pi)
    }
}
