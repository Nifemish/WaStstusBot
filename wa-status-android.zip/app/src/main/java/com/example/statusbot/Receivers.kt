package com.example.statusbot

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val s = Store(ctx)
        if (!s.enabled || s.posts.isEmpty()) return
        val posts = s.posts
        val p = posts[s.cursor % posts.size]
        s.cursor = (s.cursor + 1) % posts.size
        s.nextRun = Scheduler.computeNext(s)
        Scheduler.schedule(ctx)
        val pr = goAsync()
        Thread {
            var i = 0
            while (WaAccessibilityService.instance == null && i < 20) { Thread.sleep(500); i++ }
            val svc = WaAccessibilityService.instance
            if (svc == null) s.log("Alarm fired but Accessibility is OFF. Turn it on in the app.")
            else Handler(Looper.getMainLooper()).post { svc.startJob(p) }
            pr.finish()
        }.start()
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) { Scheduler.schedule(ctx) }
}
