package com.example.statusbot

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object Ai {
    fun captions(key: String, idea: String, tone: String, image: File?): List<String> {
        val content = JSONArray()
        if (image != null) {
            small(image)?.let {
                content.put(JSONObject().put("type", "image").put("source",
                    JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", it)))
            }
        }
        val topic = if (idea.isNotBlank()) "Topic: $idea. " else ""
        content.put(JSONObject().put("type", "text").put("text",
            "Write 3 different WhatsApp Status captions. Tone: $tone. $topic" +
                "Under 150 characters each, emojis allowed. Return ONLY a JSON array of 3 strings."))
        val body = JSONObject().put("model", "claude-sonnet-5-5").put("max_tokens", 600)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 20000; c.readTimeout = 60000
        c.setRequestProperty("content-type", "application/json")
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
        val j = JSONObject(txt)
        if (code !in 200..299) throw Exception(j.optJSONObject("error")?.optString("message") ?: "HTTP $code")
        val t = j.getJSONArray("content").getJSONObject(0).getString("text")
            .replace("```json", "").replace("```", "").trim()
        val arr = JSONArray(t)
        return (0 until minOf(3, arr.length())).map { arr.getString(it) }
    }

    private fun small(f: File): String? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / s > 1400) s *= 2
        val bm = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
        val bo = ByteArrayOutputStream()
        bm.compress(Bitmap.CompressFormat.JPEG, 80, bo)
        return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
    }
}
