package com.example.statusbot

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Post(val id: String, val file: String, val type: String, val caption: String)

class Store(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("statusbot", Context.MODE_PRIVATE)

    var posts: List<Post>
        get() {
            val a = JSONArray(sp.getString("posts", "[]"))
            return (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Post(o.getString("id"), o.getString("file"), o.getString("type"), o.optString("caption"))
            }
        }
        set(v) {
            val a = JSONArray()
            v.forEach { a.put(JSONObject().put("id", it.id).put("file", it.file).put("type", it.type).put("caption", it.caption)) }
            sp.edit().putString("posts", a.toString()).apply()
        }

    var mode: String
        get() = sp.getString("mode", "interval") ?: "interval"
        set(v) = sp.edit().putString("mode", v).apply()
    var intervalHours: Float
        get() = sp.getFloat("hrs", 23f)
        set(v) = sp.edit().putFloat("hrs", v).apply()
    var times: String
        get() = sp.getString("times", "09:00") ?: "09:00"
        set(v) = sp.edit().putString("times", v).apply()
    var enabled: Boolean
        get() = sp.getBoolean("enabled", true)
        set(v) = sp.edit().putBoolean("enabled", v).apply()
    var business: Boolean
        get() = sp.getBoolean("biz", false)
        set(v) = sp.edit().putBoolean("biz", v).apply()
    var cursor: Int
        get() = sp.getInt("cursor", 0)
        set(v) = sp.edit().putInt("cursor", v).apply()
    var nextRun: Long
        get() = sp.getLong("next", 0L)
        set(v) = sp.edit().putLong("next", v).apply()
    var statusLabel: String
        get() = sp.getString("statusLabel", "My status") ?: "My status"
        set(v) = sp.edit().putString("statusLabel", v).apply()
    var sendLabel: String
        get() = sp.getString("sendLabel", "Send") ?: "Send"
        set(v) = sp.edit().putString("sendLabel", v).apply()
    var apiKey: String
        get() = sp.getString("apiKey", "") ?: ""
        set(v) = sp.edit().putString("apiKey", v).apply()

    fun log(msg: String) = synchronized(Store::class.java) {
        val old = JSONArray(sp.getString("log", "[]"))
        val out = JSONArray()
        out.put(SimpleDateFormat("MM-dd HH:mm:ss", Locale.US).format(Date()) + " " + msg)
        for (i in 0 until minOf(old.length(), 59)) out.put(old.getString(i))
        sp.edit().putString("log", out.toString()).apply()
    }

    fun logs(): List<String> {
        val a = JSONArray(sp.getString("log", "[]"))
        return (0 until a.length()).map { a.getString(it) }
    }
}
