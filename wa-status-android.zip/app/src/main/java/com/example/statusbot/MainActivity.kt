package com.example.statusbot

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.webkit.MimeTypeMap
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private object C {
    val BG = Color.parseColor("#0E0E10")
    val CARD = Color.parseColor("#17171B")
    val LINE = Color.parseColor("#2A2A30")
    val FIELD = Color.parseColor("#202026")
    val GOLD = Color.parseColor("#C9A96E")
    val TEXT = Color.parseColor("#F5F1E8")
    val MUTED = Color.parseColor("#8E8B84")
    val OK = Color.parseColor("#8CC39A")
    val WARN = Color.parseColor("#E09A78")
}

class MainActivity : Activity() {
    private lateinit var store: Store
    private lateinit var nextTv: TextView
    private lateinit var nextSub: TextView
    private lateinit var pillTv: TextView
    private lateinit var accSt: TextView
    private lateinit var batSt: TextView
    private lateinit var queueBox: LinearLayout
    private lateinit var logTv: TextView
    private var modeSel = 0
    private var logExpanded = false
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable { override fun run() { refreshStatus(); h.postDelayed(this, 5000) } }

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    /* ---------- tiny design kit ---------- */
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun round(color: Int, r: Int = 16, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun text(t: String, size: Float = 14f, color: Int = C.TEXT, bold: Boolean = false, serif: Boolean = false) =
        TextView(this).apply {
            text = t; textSize = size; setTextColor(color)
            typeface = Typeface.create(if (serif) "serif" else "sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
        }

    private fun caps(t: String) = text(t.uppercase(), 11f, C.GOLD, true).apply {
        letterSpacing = 0.16f; setPadding(0, 0, 0, dp(10))
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = round(C.CARD, 22, C.LINE)
        setPadding(dp(20), dp(20), dp(20), dp(20))
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(14) }
    }

    private fun field(hint: String, value: String, type: Int = InputType.TYPE_CLASS_TEXT) = EditText(this).apply {
        this.hint = hint; setText(value); inputType = type
        setTextColor(C.TEXT); setHintTextColor(C.MUTED); textSize = 15f
        background = round(C.FIELD, 12)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
    }

    private fun primary(t: String, f: () -> Unit) = text(t, 15f, C.BG, true).apply {
        gravity = Gravity.CENTER
        background = round(C.GOLD, 16)
        setPadding(dp(16), dp(15), dp(16), dp(15))
        isClickable = true
        setOnClickListener { f() }
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(16) }
    }

    private fun ghost(t: String, color: Int = C.GOLD, f: () -> Unit) = text(t, 13f, color, true).apply {
        setPadding(dp(10), dp(8), dp(10), dp(8)); isClickable = true; setOnClickListener { f() }
    }

    private fun pill(t: String, f: () -> Unit) = text(t, 13f, C.GOLD, true).apply {
        background = round(0, 20, C.GOLD)
        setPadding(dp(16), dp(8), dp(16), dp(8)); isClickable = true; setOnClickListener { f() }
    }

    private fun styled(b: AlertDialog.Builder): AlertDialog {
        val d = b.create()
        d.window?.setBackgroundDrawable(round(C.CARD, 22))
        d.show()
        d.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(C.GOLD)
        d.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(C.MUTED)
        return d
    }

    private fun dialog() = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)

    private fun segmented(a: String, b: String, sel: Int, onSel: (Int) -> Unit): LinearLayout {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = round(C.FIELD, 14)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        val tabs = listOf(a, b).map { t ->
            text(t, 13f, C.MUTED, true).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(11), 0, dp(11)); isClickable = true
                layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
            }
        }
        fun paint(s: Int) = tabs.forEachIndexed { i, v ->
            v.background = if (i == s) round(C.GOLD, 11) else null
            v.setTextColor(if (i == s) C.BG else C.MUTED)
        }
        tabs.forEachIndexed { i, v -> v.setOnClickListener { paint(i); onSel(i) }; wrap.addView(v) }
        paint(sel)
        return wrap
    }

    private fun switchRow(title: String, sub: String, checked: Boolean): Pair<LinearLayout, Switch> {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(4))
        }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f) }
        left.addView(text(title, 15f))
        left.addView(text(sub, 12f, C.MUTED))
        val sw = Switch(this).apply {
            isChecked = checked
            val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            thumbTintList = ColorStateList(st, intArrayOf(C.GOLD, C.MUTED))
            trackTintList = ColorStateList(st, intArrayOf(Color.parseColor("#5A4A2A"), C.LINE))
        }
        row.addView(left); row.addView(sw)
        return row to sw
    }

    private fun setupRow(title: String, sub: String, action: () -> Unit): Pair<LinearLayout, TextView> {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f) }
        left.addView(text(title, 15f)); left.addView(text(sub, 12f, C.MUTED))
        val st = ghost("", C.GOLD, action)
        row.addView(left); row.addView(st)
        return row to st
    }

    /* ---------- screen ---------- */
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        store = Store(this)
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { Store(applicationContext).log("CRASH: ${e.javaClass.simpleName}: ${e.message}") } catch (_: Throwable) {}
            prev?.uncaughtException(t, e)
        }
        window.statusBarColor = C.BG
        window.navigationBarColor = C.BG

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(24), dp(18), dp(48)) }
        setContentView(ScrollView(this).apply { setBackgroundColor(C.BG); isVerticalScrollBarEnabled = false; addView(col) })

        // header
        col.addView(text("STATUS", 12f, C.GOLD, true).apply { letterSpacing = 0.4f })
        col.addView(text("Scheduler", 34f, C.TEXT, false, true))
        col.addView(text("Your WhatsApp Status, quietly on autopilot.", 13f, C.MUTED).apply { setPadding(0, dp(4), 0, dp(20)) })

        // hero
        val hero = card()
        hero.addView(caps("Next post"))
        nextTv = text("-", 26f, C.TEXT, false, true)
        nextSub = text("", 13f, C.MUTED).apply { setPadding(0, dp(6), 0, 0) }
        pillTv = text("", 12f, C.OK, true).apply {
            background = round(C.FIELD, 20)
            setPadding(dp(14), dp(7), dp(14), dp(7))
            layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(16) }
        }
        hero.addView(nextTv); hero.addView(nextSub); hero.addView(pillTv)
        col.addView(hero)

        // setup
        val setup = card()
        setup.addView(caps("Setup"))
        val (accRow, acc) = setupRow("Accessibility", "Lets the app tap through WhatsApp") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        val (batRow, bat) = setupRow("Background use", "Keeps posting reliable") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        accSt = acc; batSt = bat
        setup.addView(accRow); setup.addView(batRow)
        col.addView(setup)

        // schedule
        val sch = card()
        sch.addView(caps("Schedule"))
        modeSel = if (store.mode == "times") 1 else 0
        val intBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val timesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun showMode() { intBox.visibility = if (modeSel == 0) View.VISIBLE else View.GONE; timesBox.visibility = if (modeSel == 1) View.VISIBLE else View.GONE }
        sch.addView(segmented("Every N hours", "Set times daily", modeSel) { modeSel = it; showMode() })

        val hrs = field("23", fmt(store.intervalHours), InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL).apply {
            layoutParams = LinearLayout.LayoutParams(dp(90), WRAP).apply { leftMargin = dp(12); rightMargin = dp(12) }
            gravity = Gravity.CENTER
        }
        val hrow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, 0) }
        hrow.addView(text("Post every", 15f)); hrow.addView(hrs); hrow.addView(text("hours", 15f))
        intBox.addView(hrow)
        val times = field("09:00, 18:30", store.times)
        timesBox.addView(text("Daily at (your phone's timezone)", 12f, C.MUTED).apply { setPadding(0, dp(12), 0, 0) })
        timesBox.addView(times)
        sch.addView(intBox); sch.addView(timesBox); showMode()
        sch.addView(text("Statuses expire after 24 hours. Keep it at 24h or less so there's no gap.", 12f, C.MUTED).apply { setPadding(0, dp(12), 0, dp(6)) })

        val (enRow, en) = switchRow("Auto-posting", "Pause anytime without losing your queue", store.enabled)
        val (bizRow, biz) = switchRow("WhatsApp Business", "Post to Business instead of regular WhatsApp", store.business)
        sch.addView(enRow); sch.addView(bizRow)

        val adv = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val statusLbl = field("My status", store.statusLabel)
        val sendLbl = field("Send", store.sendLabel)
        val key = field("Anthropic API key", store.apiKey, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        adv.addView(text("Label of \"My status\" in your language", 12f, C.MUTED).apply { setPadding(0, dp(8), 0, 0) }); adv.addView(statusLbl)
        adv.addView(text("Label of the Send button in your language", 12f, C.MUTED).apply { setPadding(0, dp(10), 0, 0) }); adv.addView(sendLbl)
        adv.addView(text("AI captions (optional)", 12f, C.MUTED).apply { setPadding(0, dp(10), 0, 0) }); adv.addView(key)
        val advToggle = ghost("Advanced  ▾", C.MUTED) {}
        advToggle.setOnClickListener {
            val open = adv.visibility != View.VISIBLE
            adv.visibility = if (open) View.VISIBLE else View.GONE
            advToggle.text = if (open) "Advanced  ▴" else "Advanced  ▾"
        }
        sch.addView(advToggle); sch.addView(adv)
        sch.addView(primary("Save schedule") {
            store.mode = if (modeSel == 1) "times" else "interval"
            store.intervalHours = (hrs.text.toString().toFloatOrNull() ?: 23f).coerceIn(0.1f, 168f)
            store.times = times.text.toString()
            store.enabled = en.isChecked
            store.business = biz.isChecked
            store.statusLabel = statusLbl.text.toString().ifBlank { "My status" }
            store.sendLabel = sendLbl.text.toString().ifBlank { "Send" }
            store.apiKey = key.text.toString().trim()
            val now = System.currentTimeMillis()
            val c = Scheduler.computeNext(store, now)
            store.nextRun = if (store.mode == "times") c else if (store.nextRun > now) minOf(store.nextRun, c) else now + 60_000
            Scheduler.schedule(this)
            refreshStatus(); toast("Saved")
        })
        col.addView(sch)

        // queue
        val q = card()
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, 0, 0, dp(6)) }
        head.addView(caps("Queue").apply { setPadding(0, 0, 0, 0); layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f) })
        head.addView(pill("+ Add") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*"))
            }, 1)
        })
        q.addView(head)
        queueBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        q.addView(queueBox)
        col.addView(q)

        // activity log
        val lg = card()
        lg.addView(caps("Activity"))
        logTv = text("", 11f, C.MUTED).apply { typeface = Typeface.MONOSPACE }
        lg.addView(logTv)
        val more = ghost("Show all", C.MUTED) {}
        more.setOnClickListener { logExpanded = !logExpanded; more.text = if (logExpanded) "Show less" else "Show all"; refreshStatus() }
        lg.addView(more)
        col.addView(lg)

        renderQueue()
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    private fun fmt(f: Float) = if (f % 1f == 0f) f.toInt().toString() else f.toString()

    private fun a11yOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(packageName) && s.contains("WaAccessibilityService")
    }

    private fun batteryOk() = try { getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName) } catch (e: Throwable) { false }

    private fun refreshStatus() {
        val on = a11yOn()
        accSt.text = if (on) "Ready ✓" else "Turn on ›"; accSt.setTextColor(if (on) C.OK else C.WARN)
        val bo = batteryOk()
        batSt.text = if (bo) "Allowed ✓" else "Allow ›"; batSt.setTextColor(if (bo) C.OK else C.WARN)

        val n = store.posts.size
        val live = store.enabled && n > 0 && store.nextRun > 0
        nextTv.text = if (live) SimpleDateFormat("EEE, d MMM  ·  h:mm a", Locale.getDefault()).format(Date(store.nextRun)) else "Not scheduled"
        val cadence = if (store.mode == "times") "Daily at ${store.times}" else "Every ${fmt(store.intervalHours)} hours"
        nextSub.text = if (n == 0) "Add a photo or video to begin" else "$cadence  ·  $n in queue"
        val (label, color) = when {
            !on -> "Setup needed" to C.WARN
            !store.enabled -> "Paused" to C.MUTED
            n == 0 -> "Waiting for a post" to C.MUTED
            else -> "●  Active" to C.OK
        }
        pillTv.text = label; pillTv.setTextColor(color)

        val lines = store.logs().take(if (logExpanded) 30 else 5)
        logTv.text = if (lines.isEmpty()) "Nothing yet." else lines.joinToString("\n\n")
        logTv.maxLines = Int.MAX_VALUE; logTv.ellipsize = TextUtils.TruncateAt.END
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (req == 1 && res == RESULT_OK && uri != null) importMedia(uri)
    }

    private fun importMedia(uri: Uri) {
        toast("Importing…")
        Thread {
            try {
                val mime = contentResolver.getType(uri) ?: "image/jpeg"
                val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) ?: "bin"
                val dir = File(filesDir, "media").apply { mkdirs() }
                val f = File(dir, UUID.randomUUID().toString() + "." + ext)
                contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                runOnUiThread { captionDialog(f, if (mime.startsWith("video")) "video" else "image") }
            } catch (e: Exception) { runOnUiThread { toast("Import failed: ${e.message}") } }
        }.start()
    }

    private fun captionDialog(file: File, type: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(6), dp(22), dp(4)) }
        val cap = field("Write a caption…", "").apply { minLines = 3; gravity = Gravity.TOP }
        val idea = field("Idea for AI (optional)", "")
        val tones = listOf("Casual", "Funny", "Inspiring", "Professional", "Short and punchy")
        var ti = 0
        val toneTv = ghost("Tone: ${tones[0]}  ›", C.MUTED) {}
        toneTv.setOnClickListener { ti = (ti + 1) % tones.size; toneTv.text = "Tone: ${tones[ti]}  ›" }
        val ai = ghost("✨  Suggest captions") {}
        ai.setOnClickListener {
            if (store.apiKey.isBlank()) { toast("Add your Anthropic API key under Advanced first"); return@setOnClickListener }
            ai.isEnabled = false; ai.alpha = 0.5f
            val tone = tones[ti]
            Thread {
                val r = runCatching { Ai.captions(store.apiKey, idea.text.toString(), tone, if (type == "image") file else null) }
                runOnUiThread {
                    ai.isEnabled = true; ai.alpha = 1f
                    r.onSuccess { list ->
                        styled(dialog().setTitle("Pick one").setItems(list.toTypedArray<CharSequence>()) { _, i -> cap.setText(list[i]) })
                    }.onFailure { toast("AI failed: ${it.message}") }
                }
            }.start()
        }
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        tools.addView(ai); tools.addView(toneTv)
        listOf(cap, idea, tools).forEach { box.addView(it) }
        styled(dialog().setTitle("New post").setView(box)
            .setPositiveButton("Add") { _, _ ->
                store.posts = store.posts + Post(UUID.randomUUID().toString(), file.path, type, cap.text.toString())
                val now = System.currentTimeMillis()
                if (store.nextRun <= now) store.nextRun = if (store.mode == "times") Scheduler.computeNext(store) else now + 60_000
                Scheduler.schedule(this)
                renderQueue(); refreshStatus()
            }
            .setNegativeButton("Cancel") { _, _ -> file.delete() }
            .setCancelable(false))
    }

    private fun postNow(p: Post) {
        val svc = WaAccessibilityService.instance
        if (svc == null) { toast("Turn on Accessibility first"); return }
        toast("Posting. Don't touch the phone for about 30 seconds.")
        try { svc.startJob(p) } catch (e: Throwable) { store.log("CRASH: ${e.javaClass.simpleName}: ${e.message}"); refreshStatus() }
    }

    private fun thumb(p: Post) = ImageView(this).apply {
        layoutParams = LinearLayout.LayoutParams(dp(64), dp(64))
        scaleType = ImageView.ScaleType.CENTER_CROP
        background = round(C.FIELD, 14)
        clipToOutline = true; outlineProvider = ViewOutlineProvider.BACKGROUND
        val bm = runCatching {
            if (p.type == "video") {
                val r = MediaMetadataRetriever(); r.setDataSource(p.file)
                val f = r.getFrameAtTime(0); r.release(); f
            } else BitmapFactory.decodeFile(p.file, BitmapFactory.Options().apply { inSampleSize = 8 })
        }.getOrNull()
        if (bm != null) setImageBitmap(bm)
    }

    private fun renderQueue() {
        queueBox.removeAllViews()
        val ps = store.posts
        if (ps.isEmpty()) {
            queueBox.addView(text("Nothing queued yet.\nAdd your first photo or video.", 14f, C.MUTED).apply { setPadding(0, dp(8), 0, dp(4)) })
            return
        }
        val upNext = store.cursor % ps.size
        ps.forEachIndexed { i, p ->
            if (i > 0) queueBox.addView(View(this).apply { setBackgroundColor(C.LINE); layoutParams = LinearLayout.LayoutParams(MATCH, 1) })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, dp(12)) }
            row.addView(thumb(p))
            val mid = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), 0, dp(8), 0)
                layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
            }
            mid.addView(text(p.caption.ifBlank { "No caption" }, 14f, if (p.caption.isBlank()) C.MUTED else C.TEXT).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END })
            val meta = (if (p.type == "video") "Video" else "Photo") + "  ·  #${i + 1}" + if (i == upNext) "  ·  Up next" else ""
            mid.addView(text(meta, 12f, if (i == upNext) C.GOLD else C.MUTED).apply { setPadding(0, dp(3), 0, 0) })
            row.addView(mid)
            val actions = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END }
            actions.addView(ghost("Post now") { postNow(p) })
            actions.addView(ghost("Remove", C.MUTED) {
                File(p.file).delete()
                store.posts = store.posts.filter { it.id != p.id }
                Scheduler.schedule(this); renderQueue(); refreshStatus()
            })
            row.addView(actions)
            queueBox.addView(row)
        }
    }
}
