package com.example.statusbot

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.*
import java.io.File
import java.text.DateFormat
import java.util.Date
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var store: Store
    private lateinit var statusTv: TextView
    private lateinit var queueBox: LinearLayout
    private lateinit var logTv: TextView
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable { override fun run() { refreshStatus(); h.postDelayed(this, 5000) } }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
    private fun label(t: String, bold: Boolean = false, size: Float = 14f) = TextView(this).apply {
        text = t; textSize = size; setPadding(0, dp(6), 0, dp(2))
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun button(t: String, f: () -> Unit) = Button(this).apply { text = t; isAllCaps = false; setOnClickListener { f() } }
    private fun field(hint: String, value: String, type: Int = InputType.TYPE_CLASS_TEXT) =
        EditText(this).apply { this.hint = hint; setText(value); inputType = type }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        store = Store(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(32)) }
        setContentView(ScrollView(this).apply { addView(col) })

        col.addView(label("Status Scheduler", true, 22f))
        statusTv = label("")
        col.addView(statusTv)
        col.addView(button("1. Turn on Accessibility (find 'Status Scheduler')") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        col.addView(button("2. Allow background use (battery)") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) })

        col.addView(label("Schedule", true, 17f))
        val modeSp = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Every N hours", "At set times each day"))
            setSelection(if (store.mode == "times") 1 else 0)
        }
        val hrs = field("Hours between posts (e.g. 23)", store.intervalHours.toString(), InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val times = field("Times, e.g. 09:00, 18:30", store.times)
        val en = CheckBox(this).apply { text = "Auto-posting on"; isChecked = store.enabled }
        val biz = CheckBox(this).apply { text = "I use WhatsApp Business"; isChecked = store.business }
        val statusLbl = field("Text of 'My status' in your language", store.statusLabel)
        val sendLbl = field("Text of the Send button in your language", store.sendLabel)
        val key = field("Anthropic API key (optional, for AI captions)", store.apiKey, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        listOf(modeSp, hrs, times, en, biz, statusLbl, sendLbl, key).forEach { col.addView(it) }
        col.addView(label("Statuses vanish after 24h, so use 24 hours or less for no gaps. Times use your phone's timezone.", size = 12f))
        col.addView(button("Save schedule") {
            store.mode = if (modeSp.selectedItemPosition == 1) "times" else "interval"
            store.intervalHours = (hrs.text.toString().toFloatOrNull() ?: 23f).coerceIn(0.1f, 168f)
            store.times = times.text.toString()
            store.enabled = en.isChecked
            store.business = biz.isChecked
            store.statusLabel = statusLbl.text.toString().ifBlank { "My status" }
            store.sendLabel = sendLbl.text.toString().ifBlank { "Send" }
            store.apiKey = key.text.toString().trim()
            val now = System.currentTimeMillis()
            val c = Scheduler.computeNext(store, now)
            store.nextRun = if (store.mode == "times") c else if (store.nextRun > now) minOf(store.nextRun, c) else now + 60_000
            Scheduler.schedule(this)
            refreshStatus(); toast("Saved")
        })

        col.addView(label("Posts (sent in order, then it loops)", true, 17f))
        col.addView(button("+ Add photo or video") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*"))
            }, 1)
        })
        queueBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(queueBox)

        col.addView(label("Log", true, 17f))
        logTv = label("", size = 11f)
        col.addView(logTv)
        renderQueue()
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    private fun a11yOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(packageName) && s.contains("WaAccessibilityService")
    }

    private fun refreshStatus() {
        val next = if (store.enabled && store.posts.isNotEmpty() && store.nextRun > 0)
            DateFormat.getDateTimeInstance().format(Date(store.nextRun)) else "-"
        statusTv.text = "Accessibility: " + (if (a11yOn()) "ON ✅" else "OFF ❌") + "\nNext post: " + next
        logTv.text = store.logs().take(25).joinToString("\n")
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (req == 1 && res == RESULT_OK && uri != null) importMedia(uri)
    }

    private fun importMedia(uri: Uri) {
        toast("Importing…")
        Thread {
            try {
                val mime = contentResolver.getType(uri) ?: "image/jpeg"
                val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) ?: "bin"
                val dir = File(filesDir, "media").apply { mkdirs() }
                val f = File(dir, UUID.randomUUID().toString() + "." + ext)
                contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                runOnUiThread { captionDialog(f, if (mime.startsWith("video")) "video" else "image") }
            } catch (e: Exception) { runOnUiThread { toast("Import failed: ${e.message}") } }
        }.start()
    }

    private fun captionDialog(file: File, type: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        val cap = EditText(this).apply { hint = "Caption"; minLines = 2 }
        val idea = EditText(this).apply { hint = "Idea for AI (optional)" }
        val tones = listOf("Casual", "Funny", "Inspiring", "Professional", "Short and punchy")
        val toneSp = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, tones) }
        val ai = Button(this).apply { text = "✨ Suggest captions"; isAllCaps = false }
        ai.setOnClickListener {
            if (store.apiKey.isBlank()) { toast("Add your Anthropic API key in the schedule section first"); return@setOnClickListener }
            ai.isEnabled = false
            val tone = tones[toneSp.selectedItemPosition]
            Thread {
                val r = runCatching { Ai.captions(store.apiKey, idea.text.toString(), tone, if (type == "image") file else null) }
                runOnUiThread {
                    ai.isEnabled = true
                    r.onSuccess { list ->
                        AlertDialog.Builder(this).setTitle("Pick one")
                            .setItems(list.toTypedArray<CharSequence>()) { _, i -> cap.setText(list[i]) }.show()
                    }.onFailure { toast("AI failed: ${it.message}") }
                }
            }.start()
        }
        listOf(cap, idea, toneSp, ai).forEach { box.addView(it) }
        AlertDialog.Builder(this).setTitle("New post").setView(box)
            .setPositiveButton("Add") { _, _ ->
                store.posts = store.posts + Post(UUID.randomUUID().toString(), file.path, type, cap.text.toString())
                val now = System.currentTimeMillis()
                if (store.nextRun <= now) store.nextRun = if (store.mode == "times") Scheduler.computeNext(store) else now + 60_000
                Scheduler.schedule(this)
                renderQueue(); refreshStatus()
            }
            .setNegativeButton("Cancel") { _, _ -> file.delete() }
            .setCancelable(false).show()
    }

    private fun postNow(p: Post) {
        val svc = WaAccessibilityService.instance
        if (svc == null) { toast("Turn on Accessibility first (button 1)"); return }
        toast("Posting. Don't touch the phone for about 30 seconds.")
        svc.startJob(p)
    }

    private fun thumb(p: Post) = ImageView(this).apply {
        layoutParams = LinearLayout.LayoutParams(dp(60), dp(60))
        scaleType = ImageView.ScaleType.CENTER_CROP
        val bm = runCatching {
            if (p.type == "video") {
                val r = MediaMetadataRetriever(); r.setDataSource(p.file)
                val f = r.getFrameAtTime(0); r.release(); f
            } else BitmapFactory.decodeFile(p.file, BitmapFactory.Options().apply { inSampleSize = 8 })
        }.getOrNull()
        if (bm != null) setImageBitmap(bm)
    }

    private fun renderQueue() {
        queueBox.removeAllViews()
        val ps = store.posts
        if (ps.isEmpty()) queueBox.addView(label("No posts yet."))
        ps.forEachIndexed { i, p ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
            row.addView(thumb(p))
            row.addView(TextView(this).apply {
                text = "${i + 1}. " + p.caption.ifBlank { "(no caption)" }
                maxLines = 3; setPadding(dp(8), 0, dp(8), 0)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            row.addView(button("Post now") { postNow(p) }.apply { textSize = 12f })
            row.addView(button("✕") {
                File(p.file).delete()
                store.posts = store.posts.filter { it.id != p.id }
                Scheduler.schedule(this); renderQueue(); refreshStatus()
            }.apply { textSize = 12f })
            queueBox.addView(row)
        }
    }
}
