package com.example.statusbot

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.content.FileProvider
import java.io.File

class WaAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: WaAccessibilityService? = null }

    private val h = Handler(Looper.getMainLooper())
    @Volatile private var active = false
    private var clickedStatus = false
    private var sends = 0
    private var lastAct = 0L
    private var lastDump = ""
    private var dumps = 0
    private var jobId = 0

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onInterrupt() {}

    fun startJob(p: Post) {
        val s = Store(this)
        val file = File(p.file)
        if (!file.exists()) { s.log("Post file missing, skipped"); return }
        @Suppress("DEPRECATION")
        getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE, "statusbot:job")
            .acquire(90_000)
        val pkg = if (s.business) "com.whatsapp.w4b" else "com.whatsapp"
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        grantUriPermission(pkg, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = if (p.type == "video") "video/*" else "image/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            if (p.caption.isNotBlank()) putExtra(Intent.EXTRA_TEXT, p.caption)
            setPackage(pkg)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        active = true; clickedStatus = false; sends = 0; lastAct = 0L; lastDump = ""; dumps = 0
        val id = ++jobId
        try {
            startActivity(i)
            s.log("Opening WhatsApp for a post…")
        } catch (e: Exception) {
            s.log("Could not open WhatsApp: ${e.message}"); active = false; return
        }
        h.postDelayed({ if (active && id == jobId) finish(false, "Timed out. See the screen lines above.") }, 75_000)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (!active) return
        val now = System.currentTimeMillis()
        if (now - lastAct < 800) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString()?.startsWith("com.whatsapp") != true) return
        val s = Store(this)

        if (dumps < 12) {
            val seen = mutableListOf<String>()
            dump(root, seen)
            val d = seen.joinToString(" | ")
            if (d != lastDump) { lastDump = d; dumps++; s.log("Screen: $d") }
        }

        if (!clickedStatus) {
            val n = find(root) { it.text?.toString()?.trim().equals(s.statusLabel, true) }
            if (n != null && click(n)) { clickedStatus = true; lastAct = now; s.log("Tapped '${s.statusLabel}'"); return }
        }
        if (clickedStatus) {
            val send = find(root) {
                it.contentDescription?.toString()?.trim().equals(s.sendLabel, true) ||
                    it.text?.toString()?.trim().equals(s.sendLabel, true)
            }
            if (send != null && click(send)) {
                sends++; lastAct = now; s.log("Tapped '${s.sendLabel}' ($sends)")
                val id = jobId
                h.postDelayed({
                    if (active && id == jobId && System.currentTimeMillis() - lastAct >= 5000) finish(true, "Status posted")
                }, 5500)
            }
        }
    }

    private fun finish(ok: Boolean, msg: String) {
        active = false
        Store(this).log((if (ok) "✅ " else "❌ ") + msg)
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    private fun find(n: AccessibilityNodeInfo?, pred: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (n == null) return null
        if (pred(n)) return n
        for (i in 0 until n.childCount) find(n.getChild(i), pred)?.let { return it }
        return null
    }

    private fun click(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        var d = 0
        while (c != null && d < 6) {
            if (c.isClickable) return c.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            c = c.parent; d++
        }
        return false
    }

    private fun dump(n: AccessibilityNodeInfo?, out: MutableList<String>) {
        if (n == null || out.size > 40) return
        n.text?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it.take(25)) }
        n.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { out.add("[" + it.take(25) + "]") }
        for (i in 0 until n.childCount) dump(n.getChild(i), out)
    }
}
